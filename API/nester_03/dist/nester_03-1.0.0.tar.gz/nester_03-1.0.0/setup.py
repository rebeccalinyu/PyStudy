from distutils.core import setup

setup(
		name			= 'nester_03',
		version			= '1.0.0',
		py_modules		= ['nester_03'],
		author			= 'rel',
		author_email	= 'rel@gmail.com',
		url				= 'http://www.headfirstlabs.com',
		description		= 'A simple printer of nested lists',
)